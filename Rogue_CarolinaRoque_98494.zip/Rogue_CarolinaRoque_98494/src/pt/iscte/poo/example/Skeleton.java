package pt.iscte.poo.example;

import pt.iscte.poo.utils.Point2D;

public class Skeleton extends AbstractEnemyElements {

	public Skeleton(String name,Point2D position) {
		super("Skeleton",position);

	}

}
