package pt.iscte.poo.example;

public interface Update {

	void update();
}
