package pt.iscte.poo.example;

public interface Movable {

	public void move();

}
